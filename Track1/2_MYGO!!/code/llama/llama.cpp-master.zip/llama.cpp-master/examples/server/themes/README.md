# LLaMA.cpp Server Wild Theme

Simple themes directory of sample "public" directories. To try any of these add --path to your run like `server --path=wild`.

![image](wild/wild.png)
